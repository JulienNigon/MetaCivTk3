package civilisation.inspecteur.simulation.civilisations;

import civilisation.inspecteur.animations.JJPanel;
import civilisation.inspecteur.simulation.PanelModificationSimulation;

public class PanelCivilisations extends JJPanel{

	PanelModificationSimulation panelParent;
	
	public PanelCivilisations (PanelModificationSimulation panelParent){
		super();
		this.panelParent = panelParent;
	}
	
	
}
