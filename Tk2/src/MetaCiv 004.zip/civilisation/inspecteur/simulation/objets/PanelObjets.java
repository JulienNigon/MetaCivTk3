package civilisation.inspecteur.simulation.objets;

import civilisation.inspecteur.animations.JJPanel;
import civilisation.inspecteur.simulation.PanelModificationSimulation;

public class PanelObjets extends JJPanel{

	PanelModificationSimulation panelParent;
	
	public PanelObjets (PanelModificationSimulation panelParent){
		super();
		this.panelParent = panelParent;
	}
	
	
}
