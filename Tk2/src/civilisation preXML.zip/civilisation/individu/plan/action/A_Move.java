package civilisation.individu.plan.action;

import java.util.ArrayList;

import civilisation.individu.Humain;

public class A_Move extends Action{

	double angle;
	
	@Override
	public Action effectuer(Humain h) {
		System.out.println(angle);
		h.setHeading(angle);
		h.fd(1);
		
		return nextAction;
	}

	public void parametrerOption(OptionsActions option){
		super.parametrerOption(option);
		
		
		if (option.getName().equals("SOUTH")){
			angle = 270.;
		}
		else if (option.getName().equals("WEST")){
			angle = 180.;
		}
		else if (option.getName().equals("NORTH")){
			angle = 90.;
		}
		else if (option.getName().equals("EAST")){
			angle = 0.;
		}
	}
	

	/**
	 * Retourne la structure des param�tres.
	 * Permet de d�terminer la pr�sentation de la fen�tre de r�glages.
	 */
	public ArrayList<String[]> getSchemaParametres(){
		
		if (schemaParametres == null){
			schemaParametres = new ArrayList<String[]>();
			String[] directions = {"NORTH","SOUTH","WEST","EAST"};
			schemaParametres.add(directions);
		}
		return schemaParametres;	
	}
	
}
