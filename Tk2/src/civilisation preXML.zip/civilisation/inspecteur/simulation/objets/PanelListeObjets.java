package civilisation.inspecteur.simulation.objets;

import civilisation.inspecteur.animations.JJPanel;

public class PanelListeObjets extends JJPanel{

}
