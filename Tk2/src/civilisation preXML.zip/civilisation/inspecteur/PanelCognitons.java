package civilisation.inspecteur;

public class PanelCognitons {

}
