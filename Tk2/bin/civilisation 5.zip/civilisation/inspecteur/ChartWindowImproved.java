package civilisation.inspecteur;

import edu.turtlekit2.tools.chart.ChartWindow;

public class ChartWindowImproved extends ChartWindow{

}
