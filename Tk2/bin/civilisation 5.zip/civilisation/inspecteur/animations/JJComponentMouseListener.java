package civilisation.inspecteur.animations;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class JJComponentMouseListener implements MouseListener{

	JJComponent c;
	
	public JJComponentMouseListener(JJComponent c){
		this.c = c;
	}
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
