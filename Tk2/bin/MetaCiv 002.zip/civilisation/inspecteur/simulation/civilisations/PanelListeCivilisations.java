package civilisation.inspecteur.simulation.civilisations;

import civilisation.inspecteur.animations.JJPanel;

public class PanelListeCivilisations extends JJPanel{

}
