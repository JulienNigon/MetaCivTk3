package civilisation.inspecteur.simulation;

import civilisation.inspecteur.animations.JJComponent;
import civilisation.inspecteur.animations.JJPanel;

public class GItemCognitif extends JJComponent{

	public GItemCognitif(JJPanel parent, double xx, double yy, double w,
			double h) {
		super(parent, xx, yy, w, h);
		this.setDragable(true);
    	//this.setBounds((int)getXx(), (int)getYy(), 800, 800);

	}

}
