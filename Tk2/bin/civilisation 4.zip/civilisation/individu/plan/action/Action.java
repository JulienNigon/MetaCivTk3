package civilisation.individu.plan.action;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import javax.swing.ImageIcon;

import civilisation.Configuration;
import civilisation.individu.Humain;
import civilisation.inspecteur.simulation.NodeArbreActions;
import civilisation.inventaire.Objet;

public abstract class Action {

	protected Action nextAction;
	protected ArrayList<Action> listeActions;
	protected ArrayList<OptionsActions> options;
	protected ArrayList<String[]> schemaParametres;

	
	public Action(){
		listeActions = new ArrayList<Action>();
		options = new ArrayList<OptionsActions>();

	}

	public static Action actionFactory(String[] options){
		
		String s = options[0].split("\\(")[0];
		String nom = "civilisation.individu.plan.action." + s;
		//System.out.println("nom : " + nom);

		Class c;
		Action action;
		try {
			c = Class.forName(nom);
			Constructor constructor  = null;
			
			Object[] valeurs = new Object[]{};
			Class[] parametres = new Class[]{};
			
			constructor = c.getConstructor(parametres);
			action  = (Action) constructor.newInstance(valeurs);
			
			action.parametrer(options);
			return action;

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	

	
	public Action effectuer(Humain h){
		return null;
	}

	public void parametrer(String[] options){
		
		for (int i = 1; i < options.length; i++){ /*Le premier terme est le nom de l'action, on l'ignore donc*/
			//System.out.println("Chargement d'une action");
			OptionsActions option = new OptionsActions(options[i].split("\\(")[0]);
			if (options[i].split("\\(").length > 1){
				//System.out.println("Chargement d'une action avec parametres");
				String param[] = options[i].split("\\(")[1].split("\\)")[0].split(";");
				for(int j = 0; j < param.length; j++){
					if (param[j].split(" ")[0].equals("Objet")){
						//System.out.println("On cherche le parametre nomm� : " + param[j].split(" ")[1]);
						option.addParametre(Configuration.getObjetByName(param[j].split(" ")[1]));
						//System.out.println("TROUVE!");
					}
					if (param[j].split(" ")[0].equals("Pheromone")){
						option.addParametre(Configuration.getPheromoneByName(param[j].split(" ")[1]));
					}
				}
			}
			parametrerOption(option);
		}
	}
	
	/**
	 * Retourne la structure des param�tres.
	 * Permet de d�terminer la pr�sentation de la fen�tre de r�glages.
	 */
	public ArrayList<String[]> getSchemaParametres(){
		
		//Retourne null si n'est pas red�fini dans les classes filles
		return schemaParametres;	
	}
	
	
	public void parametrerOption(OptionsActions option){
		options.add(option);
	}
	
	public Action getNextAction() {
		return nextAction;
	}

	public void setNextAction(Action nextAction) {
		this.nextAction = nextAction;
	}
	
	public String toString(){
		return this.getClass().getSimpleName();
	}
	
	public ImageIcon getIcon(){
		return new ImageIcon(this.getClass().getResource("../../../inspecteur/icones/arrow-000-medium.png"));
	}

	public ArrayList<Action> getListeActions() {
		return listeActions;
	}

	public void setListeActions(ArrayList<Action> listeActions) {
		this.listeActions = listeActions;
	}
	
	public void addSousAction(Action action){
		listeActions.add(action);
	}

	public ArrayList<OptionsActions> getOptions() {
		return options;
	}

	public void setOptions(ArrayList<OptionsActions> options) {
		this.options = options;
	}

	/**
	 * Supprime les options de cette action.
	 */
	public void clearOptions(){
		options = new ArrayList<OptionsActions>();
	}

	public String getName() {
		return this.getClass().getName();
	}

	public String getSimpleName(){
		return this.getClass().getSimpleName();
	}
	
	public void addActionAfter(Action action, Action ref) {
		for (int i = 0 ; i < listeActions.size(); i++){
			if (listeActions.get(i).equals(ref)){
				//System.out.println("Action ajout�e : " + (i+1));
				listeActions.add(i+1,action);
				listeActions.get(i).setNextAction(action);
				
				if (i+2 < listeActions.size()){
					action.setNextAction(listeActions.get(i+2)); /*On reconstruit le chainage avant*/
				}
				break;
			}
			if (listeActions.get(i).getListeActions() != null){
				listeActions.get(i).addActionAfter( action , ref);
			}
		}		
	}
	
	public void addActionBefore(Action action , Action ref) {
		for (int i = 0 ; i < listeActions.size(); i++){
			if (listeActions.get(i).equals(ref)){
				System.out.println("Action ajout�e : " + (i+1));
				listeActions.add(i,action);
				if (i>0){
					listeActions.get(i-1).setNextAction(action);
				}
				action.setNextAction(listeActions.get(i+1)); /*On reconstruit le chainage*/
				break;
			}
			if (listeActions.get(i).getListeActions() != null){
				listeActions.get(i).addActionBefore( action , ref);
			}
		}
	}
	
	public void addSubAction(Action action, Action ref) {
		for (int i = 0 ; i < listeActions.size(); i++){
			if (listeActions.get(i).equals(ref)){
				System.out.println("Action ajout�e : " + (i+1));
				listeActions.get(i).getListeActions().add(0,action);
				if (listeActions.get(i).getListeActions().size()>1){
					action.setNextAction(listeActions.get(i).getListeActions().get(1));
				}
				break;
			}
			if (listeActions.get(i).getListeActions() != null){
				listeActions.get(i).addSubAction( action , ref);
			}
		}		
	}
	
	/**
	 * 
	 * @return String au format des fichiers textes .metaciv (pour enregistrer)
	 */
	public String toFormatedString(){
		if (options.size() == 0){
			return toString();
		}
		else{
			String s = toString();
			for (int i = 0; i < options.size(); i++){
				s += ",";
				s += options.get(i).toFormatedString();	
			}
			return s;
		}
	}
	
	/**
	 * Red�finir cette fonction pour les actions qui jouent le r�le de contr�leurs logiques.
	 * @return 0 si l'action est simple, sinon le nombre de sous-actions qu'elle comporte, -1 si ce nombre est illimit�
	 */
	public int getNumberActionSlot(){
		return 0;
	}

	/**
	 * Red�finir cette fonction pour donner un texte informatif aux diff�rentes actions
	 * @return un texte descriptif de l'action
	 */
	public String getInfo() {
		return "<html><b style=\"color:pink\">" + this.getSimpleName() +  " : </b>" ;
	}
}
